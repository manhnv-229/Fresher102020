﻿using System;

namespace MISA.Entity
{
    public class Class1
    {
    }
}
