﻿var Enum = {
    KeyCode = {
        RowUp: 38,
        RowDown: 40,
    }
}