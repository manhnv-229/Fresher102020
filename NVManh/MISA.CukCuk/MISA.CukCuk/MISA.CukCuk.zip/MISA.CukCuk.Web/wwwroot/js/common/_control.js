﻿$(document).ready(function () {
    new Control();
})

class Control {
    constructor() {
    }

    init() {
    }

    initEvents() {
       
        
    }
    buildElements() {
       
    }

   
}